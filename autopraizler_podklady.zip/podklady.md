# AutoPraizler M.L. – podklady pro nový web

*Sesbíráno 2. 10. 2026 z Google Maps, Firmy.cz/Mapy.com, ARES, Živéfirmy.cz a firemních letáků.*

## 1. Základní údaje

| | |
|---|---|
| Značka | **AutoPraizler M.L.** (pozor: „Praizler“ s *i* – tak je to v ARES, na Googlu i v logu) |
| Majitel | Jaroslav Praizler, OSVČ |
| IČO / DIČ | 87674343 / CZ8112101833 (registrace k DPH v ARES vedená jako *zaniklá* → dnes zřejmě neplátce, ověřit) |
| Sídlo (fakturační) | U Hřiště 280, 353 01 Velká Hleďsebe |
| Provozovna | **U Mlékárny 844/8a, 353 01 Mariánské Lázně – Úšovice** (kousek od nádraží) |
| GPS | 49.95620, 12.69333 · Plus Code XM4V+F8 |
| Telefon | +420 728 920 290 (příjem oprav) |
| E-mail | servis@autopraizler.cz |
| Web | autopraizler.cz (z mé strany nedostupný – timeout, ověřit, jestli běží); starý minisite autopraizler.sluzby.cz |
| Facebook | facebook.com/people/AutoPraizler-ML/100064057664199 |
| Datová schránka | k9k4nh8 |
| Živnost | Opravy silničních vozidel od 9. 3. 2011 → **„15 let v Mariánkách“** (majitel to sám píše v odpovědích na recenze) |

### Otevírací doba – **na každém webu jiná, nutno sjednotit**
- **Firmy.cz:** Po–Pá 8:00–12:00, 13:00–17:00; So–Ne dle telefonické domluvy
- **Google:** v pátek zavírá v 15:00 (zřejmě Po–Čt 8–17, Pá 8–15)
- **Živéfirmy.cz:** Po–Čt 8:00–17:00, Pá 8:00–15:00, So–Ne zavřeno

## 2. Hodnocení
- **Google:** ★ 4,7 / 80 recenzí – jedna 1★ z roku cca 2016, jinak skoro samé pětky
- **Firmy.cz / Mapy.com:** ★ 4,9 (97,7 %) / 8 hodnocení, **4. místo v žebříčku Autoservisy v Mariánských Lázních**
- Co lidi chválí nejčastěji: rychlost, férová cena, ochota a lidský přístup, srozumitelné vysvětlení závady, **pomoc turistům a lázeňským hostům v nouzi** (defekt před hotelem Cristal, porucha o víkendu před odjezdem, centrální zamykání na dovolené). Recepce hotelů je doporučují.
- Detail viz `recenze.md`.

## 3. Služby (sjednoceno z letáku, Firmy.cz a Živéfirmy.cz)
- Autoservis – kompletní opravy a údržba osobních, dodávkových i nákladních vozidel (**vjezd do 3,3 m výšky**); servis vozidel v záruce bez porušení záručních podmínek
- Pneuservis – přezutí, vyvážení, prodej pneu (na letáku „na počkání od 260 Kč“ – stará cena, ověřit); motoservis
- Diagnostika, autoelektronika
- Geometrie náprav
- Klimatizace – plnění a servis (stanice **TEXA R710**, chladivo R134a – ověřit, jestli i R1234yf)
- Karosárna, lakovna, oprava autolaku, míchání barev, i veteráni
- Autoskla – výměna a opravy, montáž zdarma
- Likvidace pojistných událostí (na banneru Česká pojišťovna, Allianz, ČPP)
- STK + měření emisí „na klíč“ (příprava a provedení)
- LPG/CNG – přestavby a servis, revize (u LPG „pouze Elpigas“)
- Tažná zařízení na počkání, rozvodové sady
- Autodíly a doplňky (díly srovnatelné s originálem, „ušetříte až 60 %“)
- Odtahová služba, dovoz vozidel
- Náhradní vozidlo / autopůjčovna
- Likvidace autovraků

Servisované značky (z letáku): Audi, VW, Seat, Škoda, Fiat, Opel, Peugeot, Citroën, Ford, Hyundai, Suzuki, Toyota, Nissan, Renault, Alfa Romeo, Volvo, Mercedes-Benz, BMW, Honda, Kia.
Používané díly: ATE, SKF, Gates, Bosal, Mann Filter, Fram, Castrol, ABS, QH, Sachs, Moog, Bosch, LUK, Febi Bilstein. Pneu banner: LASSA.

## 4. Fotky (složka `fotky/`)
| Soubor | Co to je | Rozlišení |
|---|---|---|
| 01_budova_exterier_dodavka_LASSA | budova z ulice, panorama | 3936×1893 |
| 02_vjezdy_autoservis_pneuservis | vjezdy do dílny | 4160×3120 |
| 03_pneuservis_vyvazovacka_detail | detail disku na vyvažovačce | 1280×720 |
| 04_dilna_zvedak_Seat_Ateca | interiér dílny, auto na zvedáku | 4080×3072 |
| 05_budova_zima_zapad_slunce | upravená fotka budovy (hero kandidát) | 2876×1915 |
| 06_leták_sluzby_znacky | starý leták – texty a seznam služeb | 3376×2361 |
| 07_reklamni_banner_logo | banner s logem a telefonem | 3718×2410 |

Z Googlu jsem stáhl jen fotky, které se zobrazí na úvodní kartě; celou galerii Google v záložce na pozadí nenačte. Vyřadil jsem 3 fotky konkurence (mj. Jaralex a Fair-Cars), které se tam míchají přes „Lidé také hledají“. **Na nový web bude potřeba nafotit novou sadu** – tým, majitel, dílna v provozu, detaily práce.

## 5. Náměty, co na web dát navíc
1. **„Jste v Mariánkách na cestách? Pomůžeme.“** – samostatná sekce pro turisty a lázeňské hosty (defekt, porucha, rychlá diagnostika) + **německá a anglická verze**. Recenze tohle téma nesou samy, žádná konkurence ho nemá.
2. **Karta na recepce hotelů** – QR kód na web/telefon pro recepce, které je už teď doporučují.
3. **Rychlá poptávka opravy** – formulář (SPZ/model, popis závady, fotka, preferovaný termín) + tlačítko volat a WhatsApp/SMS.
4. **Orientační ceník** – přezutí, geometrie, plnění klimy, STK na klíč, výměna oleje. I „od–do“ ceny zvyšují důvěru.
5. **Sezónní akce** – přezutí jaro/podzim, kontrola klimy před létem, příprava na zimu (leták zmiňuje „pravidelné sezónní akce“). Ověřit, jestli nabízí **uskladnění pneu (pneuhotel)**.
6. **Pojistné události krok za krokem** – co dělat po nehodě, s kterými pojišťovnami spolupracují, náhradní vůz během opravy.
7. **„Servis v záruce bez ztráty záruky“** – vysvětlit (lidi to často nevědí), plus úspora dílů oproti značkovým servisům.
8. **Pro firmy a flotily** – dodávky do 3,3 m, servis a STK pro firemní auta.
9. **O nás / příběh** – 15 let, Jaroslav Praizler, tým, fotky lidí. Recenze chválí hlavně lidi, proto je ukázat.
10. **Recenze** – živý widget nebo výběr citací + odkaz „napište nám recenzi“ (Google i Firmy.cz).
11. **Galerie před/po** – karosárna a lakovna se tak prodávají nejlíp.
12. **Jak k nám** – mapa, „u nádraží: nechte auto u nás a jeďte vlakem/do lázní“, parkoviště.
13. **FAQ** – jak dlouho trvá přezutí, jestli čekat na místě, platba kartou, víkendy.
14. **Technické SEO** – schema.org AutoRepair, sjednotit NAP a otevírací dobu na Googlu, Firmy.cz, Facebooku a Živéfirmách; Google Business profil propojit s webem.

## 6. Co potřebujeme od Jardy
- Aktuální otevírací doba (jedna pravda pro všechny weby)
- Které služby pořád platí (motoservis, autopůjčovna, odtah, LPG/CNG, autovraky?) a orientační ceny
- Logo ve vektoru (máme jen bitmapu z banneru), barvy (oranžová/černá)
- Fotky týmu a dílny, případně svolení k focení
- Přístupy k doméně autopraizler.cz, hostingu a e-mailu; Google Business profilu
- Jestli chce DE/EN verzi a online objednávky
- Plátce/neplátce DPH (kvůli cenám na webu)

## Zdroje
- [Google Maps – AutoPraizler M.L.](https://www.google.com/maps/place/AutoPraizler+M.L./@49.9562027,12.6933457,17z/data=!4m6!3m5!1s0x47a07d1604f06a21:0xad665f55c029a4d3!8m2!3d49.9562027!4d12.6933457)
- [Firmy.cz – AutoPraizler](https://www.firmy.cz/detail/2642756-autopraizler-marianske-lazne-usovice.html)
- [ARES – IČO 87674343](https://ares.gov.cz/ekonomicke-subjekty?ico=87674343)
- [Živéfirmy.cz](https://www.zivefirmy.cz/praizler-jaroslav_f1287131)
- [autopraizler.sluzby.cz](https://autopraizler.sluzby.cz/)
- [Facebook AutoPraizler M.L.](https://www.facebook.com/people/AutoPraizler-ML/100064057664199/)
